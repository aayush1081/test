# inShare file sharing app apis

Rest api using Node, Express, Mongo.
We will build rest api for a simple file sharing app. 

![demo gif](https://github.com/ShivamJoker/GIF-Demos/raw/master/inshare%20demo.gif)

<!-- ### Frontend source code can be found on @ShivamJoker Github
https://github.com/ShivamJoker/InShare


## Installation 
After download or clone run `npm install` OR `yarn install` to install all the dependancies.
also do not forget to rename `.env.example` into `.env` an put all creadentials.

🙏 If you find this repo helpful then don't forget to give a start ❇️ to this repository. :) -->
